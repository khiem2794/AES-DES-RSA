# Beego 示例

本项目主要用于展示 beego 示例应用程序，您可以通过它更好地学习如何使用 beego，或提交一个 issue 告诉我们您期待的示例。当然，您也可以通过 pull request 向我们提交您的示例。

## 示例

- [在线聊天室](WebIM/README_ZH.md)：基于长轮询和 WebSocket 的聊天室。
- [短域名](shorturl/README_ZH.md):基于beego开发的API应用，短域名服务。
- [Todo](todo/README_ZH.md):基于beego开发的Web应用，后端采用API开发，angularJS开发界面。