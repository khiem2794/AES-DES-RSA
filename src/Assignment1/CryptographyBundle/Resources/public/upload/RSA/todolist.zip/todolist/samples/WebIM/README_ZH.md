# 在线聊天室

[English](./README.md)

本示例通过使用长轮询和 WebSocket 基于 beego 构建一个基于网页的聊天室。

- [详细文档](http://beego.me/docs/examples/chat.md)
