# Shorturl

[中文文档](./README_ZH.md)

This sample is a API application based on beego. It has two API func:

- /v1/shorten
- /v1/expand
