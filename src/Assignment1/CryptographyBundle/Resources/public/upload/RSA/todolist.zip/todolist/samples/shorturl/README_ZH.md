# Shorturl

[English](./README.md)

这个例子演示了如何使用beego开发API应用. 他包含了两个API接口:

- /v1/shorten
- /v1/expand
